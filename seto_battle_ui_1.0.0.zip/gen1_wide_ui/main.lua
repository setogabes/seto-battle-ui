local Font = require("src.render.Font")
local Strings = require("src.core.Strings")
local TypeChart = require("src.battle.TypeChart")
local Theme = require("src.ui.Theme")
local Growth = require("src.pokemon.Growth")

-- Gen 1 Wide Battle UI 0.2.78
-- Target: Gen1Recomp 0.2.15 + DramaticShapeVoxelMod/PotatoVoxel 1.8.3.
-- Only the UI presentation is replaced; battle sprites/camera remain native.

return function(mod)
  local activeBattle = nil

  -- Tabela que guardará nossas texturas customizadas
  local CustomTheme = {
    enemy_top_bg = nil, player_top_bg = nil, main_menu_bg = nil,
    message_bg = nil, moves_left_bg = nil, moves_right_bg = nil,
    bag_bg = nil, party_bg = nil, summary_bg = nil,
    btn_fight = nil, btn_item = nil, btn_pkmn = nil, btn_run = nil,
    party_slot_bg = nil,
    types = {},
    type_luminance = {}
  }

  -- Guarda o tema ativo para não recarregar as imagens o tempo todo
  local currentLoadedTheme = nil 
  local currentThemeIsDark = false

  -- Função que carrega as imagens baseada no nome da pasta
  local function LoadCustomAssets(themeFolder)
    themeFolder = themeFolder or "default"
    
    -- Se for o tema padrão, limpamos as imagens e voltamos ao visual original
    if themeFolder == "default" then
      for k in pairs(CustomTheme) do 
        if k ~= "types" and k ~= "type_luminance" then CustomTheme[k] = nil end
      end
      CustomTheme.types = {}
      CustomTheme.type_luminance = {}
      currentThemeIsDark = false
      return
    end

    -- Monta o caminho dinamicamente de acordo com a pasta escolhida
    local ui_path = "assets/custom_ui/" .. themeFolder .. "/"
    
    local themeTotalLuminance = 0
    local themeLumCount = 0
    
    local function safeLoad(filename)
        local relativePath = ui_path .. filename
        
        -- Resolve o caminho virtual dentro do mod (necessário no Gen1Recomp)
        local ok, fullPath = pcall(function() return mod.assets:path(relativePath) end)
        if not ok or type(fullPath) ~= "string" then fullPath = relativePath end
        
        -- Carregamento Direto: Garante que transparências (Alpha) dos PNGs sejam processadas nativamente pela engine.
        local imgSuccess, img = pcall(love.graphics.newImage, fullPath)
        if not imgSuccess then
            imgSuccess, img = pcall(love.graphics.newImage, relativePath)
        end
        
        local calculatedLum = nil
        
        if imgSuccess and img then
            img:setFilter("nearest", "nearest")
            
            -- Avalia o contraste em background OU assets de tipagem
            if filename:match("_bg%.png$") or filename:match("^type_.*%.png$") then
                pcall(function()
                    -- Carrega os dados brutos de forma isolada apenas para leitura matemática
                    local dataSuccess, imgData = pcall(love.image.newImageData, fullPath)
                    if not dataSuccess then
                        dataSuccess, imgData = pcall(love.image.newImageData, relativePath)
                    end
                    
                    if dataSuccess and imgData then
                        local w, h = imgData:getDimensions()
                        local stepX = math.max(1, math.floor(w / 10))
                        local stepY = math.max(1, math.floor(h / 10))
                        local localLum = 0
                        local localCount = 0
                        
                        for py = 0, h - 1, stepY do
                            for px = 0, w - 1, stepX do
                                local r, g, b, a = imgData:getPixel(px, py)
                                r = type(r) == "number" and r or 1
                                g = type(g) == "number" and g or 1
                                b = type(b) == "number" and b or 1
                                a = type(a) == "number" and a or 1
                                
                                if r > 1 or g > 1 or b > 1 then r, g, b = r/255, g/255, b/255 end
                                if a > 1 then a = a / 255 end
                                
                                if a > 0.2 then
                                    localLum = localLum + (0.299 * r + 0.587 * g + 0.114 * b)
                                    localCount = localCount + 1
                                end
                            end
                        end
                        
                        if localCount > 0 then
                            calculatedLum = localLum / localCount
                            -- Se for background, adiciona na média global do tema
                            if filename:match("_bg%.png$") then
                                themeTotalLuminance = themeTotalLuminance + calculatedLum
                                themeLumCount = themeLumCount + 1
                            end
                        end
                        
                        if type(imgData.release) == "function" then pcall(function() imgData:release() end) end
                    end
                end)
            end
            
            return img, calculatedLum
        end
        
        return nil, nil
    end

    CustomTheme.enemy_top_bg, _   = safeLoad("enemy_top_bg.png")
    CustomTheme.player_top_bg, _  = safeLoad("player_top_bg.png")
    CustomTheme.main_menu_bg, _   = safeLoad("main_menu_bg.png")
    CustomTheme.message_bg, _     = safeLoad("message_bg.png")
    CustomTheme.moves_left_bg, _  = safeLoad("moves_left_bg.png")
    CustomTheme.moves_right_bg, _ = safeLoad("moves_right_bg.png")
    CustomTheme.bag_bg, _         = safeLoad("bag_bg.png")
    CustomTheme.party_bg, _       = safeLoad("party_bg.png")
    CustomTheme.summary_bg, _     = safeLoad("summary_bg.png")
    
    CustomTheme.btn_fight, _      = safeLoad("btn_fight.png")
    CustomTheme.btn_item, _       = safeLoad("btn_item.png")
    CustomTheme.btn_pkmn, _       = safeLoad("btn_pkmn.png")
    CustomTheme.btn_run, _        = safeLoad("btn_run.png")
    
    CustomTheme.party_slot_bg, _  = safeLoad("party_slot_bg.png")
    
    -- Carregamento dinâmico de tags de tipo e sua luminância para contraste de texto
    CustomTheme.types = {}
    CustomTheme.type_luminance = {}
    local typeList = {
      "normal", "fire", "water", "electric", "grass", "ice", "fighting", "poison", "ground", 
      "flying", "psychic", "bug", "rock", "ghost", "dragon", "dark", "steel", "fairy"
    }
    for _, tName in ipairs(typeList) do
      local img, lum = safeLoad("type_" .. tName .. ".png")
      CustomTheme.types[tName] = img
      CustomTheme.type_luminance[tName] = lum
    end

    -- Calcula o contraste médio com base nas coletas dos backgrounds
    if themeLumCount > 0 then
        local avgLum = themeTotalLuminance / themeLumCount
        currentThemeIsDark = (avgLum < 0.55)
    else
        currentThemeIsDark = false
    end
  end

  -- Executa o carregamento das texturas customizadas ao iniciar o script
  LoadCustomAssets("default")
  currentLoadedTheme = "default"

  -- Use the bundled Pokemon Classic TTF for text rendered by this mod.
  mod.content.font:register("ttf", {
    file = mod.assets:path("assets/fonts/Pokemon Classic.ttf"),
    size = 8,
    spacing = 0,
    bold = false,
  })

  do
    local originalAdvanceOf = Font.advanceOf
    Font.advanceOf = function(code)
      local w = originalAdvanceOf(code)
      if Font.TTF_BASE and code and code >= Font.TTF_BASE then
        local cp = code - Font.TTF_BASE
        if cp == 105 or cp == 108 then
          return math.max(1, w - 1)
        end
      end
      return w
    end
  end

  -- Varre a pasta custom_ui para criar as opções de temas dinamicamente
  local function getThemeChoices()
    local choices = { { "DEFAULT", "default" } }
    local seen = { default = true }

    local function scanDir(path)
      if love and love.filesystem and love.filesystem.getDirectoryItems then
        local ok, items = pcall(love.filesystem.getDirectoryItems, path)
        if ok and type(items) == "table" then
          for _, item in ipairs(items) do
            if not seen[item] then
              local itemPath = path .. "/" .. item
              local isDir = false
              
              -- Tenta usar getInfo (Padrão LÖVE 11.0+)
              local infoOk, info = pcall(love.filesystem.getInfo, itemPath)
              if infoOk and info then
                isDir = (info.type == "directory")
              else
                -- Fallback: isDirectory (LÖVE antigo)
                local dirOk, dirRes = pcall(love.filesystem.isDirectory, itemPath)
                if dirOk and dirRes then
                  isDir = true
                else
                  -- Fallback bruto: se conseguirmos listar itens dentro, é uma pasta
                  local tryItemsOk, tryItems = pcall(love.filesystem.getDirectoryItems, itemPath)
                  if tryItemsOk and type(tryItems) == "table" then
                    isDir = true
                  end
                end
              end

              if isDir then
                table.insert(choices, { string.upper(item), item })
                seen[item] = true
              end
            end
          end
        end
      end
    end

    -- Escaneia usando os possíveis caminhos raiz do modloader
    local ok, resolvedPath = pcall(function() return mod.assets:path("assets/custom_ui") end)
    if ok and type(resolvedPath) == "string" then scanDir(resolvedPath) end
    
    local ok2, resolvedPath2 = pcall(function() return mod.assets:path("assets/custom_ui/") end)
    if ok2 and type(resolvedPath2) == "string" then scanDir(resolvedPath2) end

    -- Fallback final para caminho relativo direto
    scanDir("assets/custom_ui")

    return choices
  end

  mod.options:define({
    { key = "ui_theme", type = "choice", label = "BATTLE UI THEME", default = "default",
      choices = getThemeChoices(),
      help = "Escolha o tema visual da interface de batalha." },
    { key = "text_color", type = "choice", label = "TEXT COLOR (UI)", default = "auto",
      choices = {
        { "AUTO (CONTRAST)", "auto" },
        { "BLACK", "black" },
        { "WHITE (DARK BG)", "white" },
      },
      help = "Muda a cor da fonte global. AUTO detecta contraste automaticamente." },
    { key = "wide_top", type = "toggle", label = "WIDE TOP UI", default = false,
      help = "Spread only the upper status panels toward the left/right screen margins." },
    { key = "top_ui_scale", type = "choice", label = "TOP UI SCALE", default = "100",
      choices = {
        { "10%", "10" }, { "20%", "20" }, { "30%", "30" }, { "40%", "40" },
        { "50%", "50" }, { "60%", "60" }, { "70%", "70" }, { "80%", "80" },
        { "90%", "90" }, { "100%", "100" }, { "110%", "110" }, { "120%", "120" },
        { "130%", "130" }, { "140%", "140" }, { "150%", "150" },
      },
      help = "Scale only the upper battle UI elements; their anchors stay fixed." },
    { key = "bottom_ui_scale", type = "choice", label = "BOTTOM UI SCALE", default = "100",
      choices = {
        { "10%", "10" }, { "20%", "20" }, { "30%", "30" }, { "40%", "40" },
        { "50%", "50" }, { "60%", "60" }, { "70%", "70" }, { "80%", "80" },
        { "90%", "90" }, { "100%", "100" },
      },
      help = "Scale only the lower battle UI inside its 100% bounds." },
    { key = "bottom_message_font", type = "choice", label = "BOTTOM MESSAGE FONT", default = "0",
      choices = {
        { "0% (CURRENT)", "0" }, { "10%", "10" }, { "20%", "20" }, { "30%", "30" },
        { "40%", "40" }, { "50%", "50" }, { "60%", "60" }, { "70%", "70" },
        { "80%", "80" }, { "90%", "90" }, { "100%", "100" },
      },
      help = "Adjust only battle messages rendered in the lower message box." },
  })

  local function wideTopEnabled()
    local ok, v = pcall(mod.options.get, mod.options, "wide_top")
    return ok and v == true
  end

  local function optionScale(key, minValue, maxValue)
    local ok, v = pcall(mod.options.get, mod.options, key)
    local n = tonumber(ok and v or 100) or 100
    n = math.max(minValue, math.min(maxValue, n))
    return n / 100
  end

  local function topUIScaleMultiplier()
    return optionScale("top_ui_scale", 10, 150)
  end

  local function bottomUIScaleMultiplier()
    return optionScale("bottom_ui_scale", 10, 100)
  end

  local function bottomMessageFontMultiplier()
    local ok, v = pcall(mod.options.get, mod.options, "bottom_message_font")
    local n = tonumber(ok and v or 0) or 0
    n = math.max(0, math.min(100, n))
    return 1 + (n / 100)
  end

  -- Helpers para cores de texto e preenchimento de caixas
  local function getTextColor()
    local ok, val = pcall(mod.options.get, mod.options, "text_color")
    if ok and val == "white" then return 1, 1, 1, 1 end
    if ok and val == "black" then return 0, 0, 0, 1 end
    
    -- Fallback padrão para AUTO
    if currentThemeIsDark then return 1, 1, 1, 1 end
    return 0, 0, 0, 1
  end

  local function getBoxFillColor()
    local r = getTextColor()
    if r == 1 then return 0.15, 0.15, 0.15, 0.94 end 
    return 1, 1, 1, 0.94
  end

  local UI_SCALE = 1.00
  local LOGICAL_W, LOGICAL_H = 304, 144
  local REF_W, REF_H = 1920, 1080
  local BASE_LOGICAL_SCALE = REF_W / LOGICAL_W

  local function getResponsiveTransform(viewport)
    local ww = tonumber(viewport and viewport.width) or 0
    local wh = tonumber(viewport and viewport.height) or 0
    if ww <= 0 or wh <= 0 then return nil end
    local frameScale = math.min(ww / REF_W, wh / REF_H)
    local logicalScale = BASE_LOGICAL_SCALE * frameScale
    local ox = (ww - REF_W * frameScale) / 2
    local oy = (wh - REF_H * frameScale) / 2
    return logicalScale, ox, oy, frameScale
  end

  local function responsiveLogicalWidth(viewport, frameScale)
    local ww = tonumber(viewport and viewport.width) or 0
    if ww <= 0 or not frameScale or frameScale <= 0 then return LOGICAL_W end
    return ww / (BASE_LOGICAL_SCALE * frameScale)
  end

  local PANEL_W = 76
  local PANEL_H = 34
  local ANGLE = 7
  local INNER = 5
  local BAR_W = 50
  local BAR_H = 4
  local TEXT_SCALE = 0.58
  local INFO_TOP = 5
  local INFO_STEP = 7
  local LEFT_X = 14
  local TOP_Y = 11
  local PLAYER_X = LOGICAL_W - LEFT_X - PANEL_W
  local PLAYER_Y = 64
  local BALL_SIZE = 5
  local PARTY_BALL_SIZE = 9.45

  local MENU_X = 0
  local MENU_Y = 108
  local DEFAULT_MENU_Y = MENU_Y
  local COMMAND_BOX_SCALE = 0.75
  local MENU_W = 296
  local MENU_H = 48
  local MOVE_LEFT_W = 184
  local MOVE_RIGHT_X = MENU_X + MOVE_LEFT_W + 8
  local MOVE_RIGHT_W = MENU_W - MOVE_LEFT_W - 8

  local PARTY_W, PARTY_H = 272, 112
  local BAG_W, BAG_H = 272, 112
  local PARTY_X = math.floor((LOGICAL_W - PARTY_W) / 2)
  local PARTY_Y = 16
  local BAG_X = math.floor((LOGICAL_W - BAG_W) / 2)
  local BAG_Y = 16
  local SUMMARY_W, SUMMARY_H = 272, 112
  local SUMMARY_X = math.floor((LOGICAL_W - SUMMARY_W) / 2)
  local SUMMARY_Y = 16

  -- Helper que desenha o BG com o Sistema de Ancoragem (Anchors)
  local function drawCustomBg(img, x, y, targetW, targetH, anchor)
    love.graphics.setColor(1, 1, 1, 1) -- Reseta cor pra não escurecer a imagem
    local iw, ih = img:getDimensions()
    
    if anchor == "top-left" or anchor == "bottom-left" then
      local drawX = x
      local drawY = y + targetH - ih
      love.graphics.draw(img, math.floor(drawX), math.floor(drawY))
      
    elseif anchor == "top-right" or anchor == "bottom-right" then
      local drawX = x + targetW - iw
      local drawY = y + targetH - ih
      love.graphics.draw(img, math.floor(drawX), math.floor(drawY))
      
    elseif anchor == "bottom-center" then
      local drawX = x + (targetW / 2) - (iw / 2)
      local drawY = y + targetH - ih
      love.graphics.draw(img, math.floor(drawX), math.floor(drawY))
      
    else
      local sx = targetW / iw
      local sy = targetH / ih
      love.graphics.draw(img, math.floor(x), math.floor(y), 0, sx, sy)
    end
  end

  local function width(text)
    local ok, w = pcall(Font.width, tostring(text))
    if ok and type(w) == "number" then return w end
    return #tostring(text) * 6
  end

  local function drawText(text, x, y, scale)
    love.graphics.setColor(getTextColor())
    if scale and scale ~= 1 then
      love.graphics.push()
      love.graphics.translate(math.floor(x + 0.5), math.floor(y + 0.5))
      love.graphics.scale(scale, scale)
      Font.draw(tostring(text), 0, 0)
      love.graphics.pop()
    else
      Font.draw(tostring(text), math.floor(x + 0.5), math.floor(y + 0.5))
    end
  end

  local function drawCursor(x, y, scale)
    local sc = scale or 1
    love.graphics.setColor(getTextColor())
    love.graphics.push()
    love.graphics.translate(math.floor(x + 0.5), math.floor(y + 0.5))
    love.graphics.scale(sc, sc)
    Font.drawCode(Theme.cursor, 0, 0)
    love.graphics.pop()
  end

  local function drawCenteredText(text, cx, y, scale)
    local sc = scale or 1
    local w = width(text) * sc
    local x = cx - w / 2
    love.graphics.setColor(getTextColor())
    love.graphics.push()
    love.graphics.translate(math.floor(x + 0.5), math.floor(y + 0.5))
    love.graphics.scale(sc, sc)
    Font.draw(tostring(text), 0, 0)
    love.graphics.pop()
  end

  -- DrawCenteredTextZoom agora aceita uma cor de override (útil para texto por cima de tags de Tipo)
  local function drawCenteredTextZoom(text, cx, cy, scale, zoom, overrideColor)
    if not text or text == "" then return end
    local sc = scale or 1
    local z = zoom or 1
    
    local resW = 0
    if type(width) == "function" then
      local okW, wVal = pcall(width, tostring(text))
      if okW and wVal then resW = wVal end
    end

    local baseFontHeight = 7 
    local yOffset = 0 
    
    local textX = -(resW / 2)
    local textY = -(baseFontHeight / 2) + yOffset

    if overrideColor then
      love.graphics.setColor(overrideColor[1], overrideColor[2], overrideColor[3], overrideColor[4])
    else
      love.graphics.setColor(getTextColor())
    end

    love.graphics.push()
    local ok, err = pcall(function()
      love.graphics.translate(math.floor(cx), math.floor(cy))
      love.graphics.scale(z * sc, z * sc)
      Font.draw(tostring(text), math.floor(textX), math.floor(textY))
    end)
    love.graphics.pop()
  end

  local function drawCommandTextZoom(text, cx, y, zoom)
    local sx, sy = 0.86, 1.08
    local w = width(text) * sx
    local x = math.floor(cx - w / 2 + 0.5)
    local pivotX, pivotY = cx, y + 4
    love.graphics.setColor(getTextColor())
    love.graphics.push()
    love.graphics.translate(pivotX, pivotY)
    love.graphics.scale(zoom or 1, zoom or 1)
    love.graphics.translate(-pivotX, -pivotY)
    love.graphics.translate(x, math.floor(y + 0.5))
    love.graphics.scale(sx, sy)
    Font.draw(tostring(text), 0, 0)
    love.graphics.translate(0.22, 0)
    Font.draw(tostring(text), 0, 0)
    love.graphics.pop()
  end

  local function drawCommandText(text, cx, y)
    local sx, sy = 0.86, 1.08
    local w = width(text) * sx
    local x = math.floor(cx - w / 2 + 0.5)
    love.graphics.setColor(getTextColor())
    love.graphics.push()
    love.graphics.translate(x, math.floor(y + 0.5))
    love.graphics.scale(sx, sy)
    Font.draw(tostring(text), 0, 0)
    love.graphics.translate(0.22, 0)
    Font.draw(tostring(text), 0, 0)
    love.graphics.pop()
  end

  local function drawCodeLineScaled(line, x, y, scale)
    local sc = scale or 1
    love.graphics.setColor(getTextColor())
    love.graphics.push()
    love.graphics.translate(math.floor(x + 0.5), math.floor(y + 0.5))
    love.graphics.scale(sc, sc)
    
    local currentX = 0
    for i = 1, #line do 
      local code = line[i]
      Font.drawCode(code, currentX, 0)
      currentX = currentX + (Font.advanceOf(code) or 8)
    end
    
    love.graphics.pop()
  end

  local function hp(battler)
    local mon = battler and battler.mon
    local cur = battler and battler.shownHP
    if cur == nil and mon then cur = mon.hp end
    local max = mon and mon.stats and mon.stats.hp or 1
    cur = math.max(0, math.floor((cur or 0) + 0.0001))
    max = math.max(1, math.floor(max))
    return cur, max
  end

  local function hpColor(cur, max)
    local ratio = cur / math.max(1, max)
    if ratio <= 0.25 then return 0.90, 0.08, 0.08 end
    if ratio <= 0.50 then return 0.95, 0.55, 0.05 end
    return 0.08, 0.72, 0.08
  end

  local function expProgress(mon, battle)
    if not mon then return 0 end
    local level = math.max(1, math.floor(mon.level or 1))
    local cap = battle and battle.data and battle.data.constants
      and battle.data.constants.levelCap or 100
    if level >= cap then return 1 end
    local speciesDef = battle and battle.data and battle.data.pokemon
      and battle.data.pokemon[mon.species]
    if not speciesDef or not speciesDef.growthRate then return 0 end
    local current = math.max(0, tonumber(mon.exp) or 0)
    local levelStart = Growth.expForLevel(speciesDef.growthRate, level,
      battle.data.growth_rates)
    local nextLevel = Growth.expForLevel(speciesDef.growthRate, level + 1,
      battle.data.growth_rates)
    local span = math.max(1, nextLevel - levelStart)
    return math.max(0, math.min(1, (current - levelStart) / span))
  end

  local EXP_BAR_W = PANEL_W - ANGLE
  local EXP_BAR_H = BAR_H
  local EXP_TRACK = { 0.20, 0.20, 0.20, 1 }
  local EXP_FILL = { 0.45, 0.78, 1.00, 1 }
  local expAnimations = setmetatable({}, { __mode = "k" })

  local function expLevelForValue(battle, mon, exp)
    local def = battle and battle.data and battle.data.pokemon
      and battle.data.pokemon[mon and mon.species]
    if not def then return mon and mon.level or 1 end
    local cap = battle.data.constants and battle.data.constants.levelCap or 100
    local value = math.max(0, math.floor(exp))
    local lo, hi = 1, cap
    while lo < hi do
      local mid = math.floor((lo + hi + 1) / 2)
      local threshold = Growth.expForLevel(def.growthRate, mid, battle.data.growth_rates)
      if threshold <= value then lo = mid else hi = mid - 1 end
    end
    return math.max(1, math.min(cap, lo))
  end

  local function expLevelAndSpan(battle, mon, exp)
    local def = battle and battle.data and battle.data.pokemon
      and battle.data.pokemon[mon and mon.species]
    if not def then return mon and mon.level or 1, 1, 0 end
    local cap = battle.data.constants and battle.data.constants.levelCap or 100
    local level = expLevelForValue(battle, mon, exp)
    level = math.max(1, math.min(cap, level or mon.level or 1))
    if level >= cap then return level, 1, 1 end
    local levelStart = Growth.expForLevel(def.growthRate, level, battle.data.growth_rates)
    local nextLevel = Growth.expForLevel(def.growthRate, level + 1, battle.data.growth_rates)
    return level, math.max(1, nextLevel - levelStart), levelStart
  end

  local function expPixelsAt(battle, mon, exp)
    if not (battle and mon) then return 0 end
    local def = battle.data and battle.data.pokemon and battle.data.pokemon[mon.species]
    if not def then return 0 end
    local cap = battle.data.constants and battle.data.constants.levelCap or 100
    local level = expLevelForValue(battle, mon, exp)
    level = math.max(1, math.min(cap, level or mon.level or 1))
    if level >= cap then return EXP_BAR_W end
    local current = Growth.expForLevel(def.growthRate, level, battle.data.growth_rates)
    local nextLevel = Growth.expForLevel(def.growthRate, level + 1, battle.data.growth_rates)
    local span = math.max(1, nextLevel - current)
    local value = math.max(current, math.min(nextLevel, math.floor(exp)))
    return math.max(0, math.min(EXP_BAR_W,
      math.floor((value - current) * EXP_BAR_W / span + 0.0001)))
  end

  local function animatedExpPixels(battle)
    local mon = battle and battle.player and battle.player.mon
    if not mon then return 0 end
    local liveExp = math.max(0, math.floor(mon.exp or 0))
    local state = expAnimations[battle]
    if not state then return expPixelsAt(battle, mon, liveExp) end

    local frame = battle.frame or 0
    if state.lastFrame == frame then
      return expPixelsAt(battle, mon, state.displayExp)
    end
    state.lastFrame = frame

    if state.displayExp == nil then state.displayExp = state.fromExp end
    if state.displayExp == state.toExp then
      expAnimations[battle] = nil
      return expPixelsAt(battle, mon, liveExp)
    end

    state.tick = (state.tick or 0) + 1
    if state.tick < 2 then
      return expPixelsAt(battle, mon, state.displayExp)
    end
    state.tick = 0

    local level, span = expLevelAndSpan(battle, mon, state.displayExp)
    local step = math.max(1, span / EXP_BAR_W)
    if state.toExp > state.displayExp then
      state.displayExp = math.min(state.toExp, state.displayExp + step)
    else
      state.displayExp = math.max(state.toExp, state.displayExp - step)
    end

    if math.abs(state.toExp - state.displayExp) < 1 then
      state.displayExp = state.toExp
    end
    return expPixelsAt(battle, mon, state.displayExp)
  end

  local function drawExpBar(battle, x, y, w)
    local mon = battle and battle.player and battle.player.mon
    if not mon then return end
    local fillPixels = animatedExpPixels(battle)
    local bw = math.floor(w + 0.5)
    local h = EXP_BAR_H

    love.graphics.setColor(0, 0, 0, 1)
    love.graphics.rectangle("fill", math.floor(x + 0.5), math.floor(y + 0.5), bw, h)
    love.graphics.setColor(EXP_TRACK[1], EXP_TRACK[2], EXP_TRACK[3], EXP_TRACK[4])
    love.graphics.rectangle("fill", math.floor(x + 1.5), math.floor(y + 1.5),
      math.max(0, bw - 2), h - 2)
    if fillPixels > 0 then
      local fill = math.min(bw - 2, fillPixels)
      love.graphics.setColor(EXP_FILL[1], EXP_FILL[2], EXP_FILL[3], EXP_FILL[4])
      love.graphics.rectangle("fill", math.floor(x + 1.5), math.floor(y + 1.5),
        fill, h - 2)
    end
  end

  local function drawBar(x, y, cur, max, w)
    local bw = w or BAR_W
    local fill = math.max(0, math.min(1, cur / math.max(1, max)))
    love.graphics.setColor(0, 0, 0, 1)
    love.graphics.rectangle("fill", x, y, bw, BAR_H)
    if fill > 0 then
      local r, g, b = hpColor(cur, max)
      love.graphics.setColor(r, g, b, 1)
      love.graphics.rectangle("fill", x + 1, y + 1,
        math.max(0, (bw - 2) * fill), BAR_H - 2)
    end
  end

  local function panelPolygon(x, y, w, h, side, inset)
    local i = inset or 0
    local a = ANGLE
    local l, t = x + i, y + i
    local r, b = x + w - i, y + h - i
    if side == "left" then
      return { l, t, r, t, r, b - a, r - a, b, l, b }
    end
    return { l, t, r, t, r, b, l + a, b, l, b - a }
  end

  local function frame(x, y, w, h, side)
    love.graphics.setColor(getTextColor())
    love.graphics.setLineWidth(1)
    love.graphics.polygon("line", panelPolygon(x, y, w, h, side, 0))
  end

  local function fillPanel(x, y, w, h, side)
    love.graphics.setColor(getBoxFillColor())
    love.graphics.polygon("fill", panelPolygon(x, y, w, h, side, 1))
  end

  local function drawMenuBox(x, y, w, h)
    love.graphics.setColor(getBoxFillColor())
    love.graphics.rectangle("fill", math.floor(x + 0.5), math.floor(y + 0.5),
      math.floor(w + 0.5), math.floor(h + 0.5))
    love.graphics.setColor(getTextColor())
    love.graphics.setLineWidth(1)
    love.graphics.rectangle("line", math.floor(x + 0.5), math.floor(y + 0.5),
      math.floor(w + 0.5), math.floor(h + 0.5))
  end

  local visualToNative = { 1, 3, 2, 4 }
  local nativeToVisual = { 1, 3, 2, 4 }

  local function drawDefaultMenu(battle)
    local labels = { Strings("FIGHT", "battle"), "ITEM", "PKMN", Strings("RUN", "battle") }
    local btn_imgs = { CustomTheme.btn_fight, CustomTheme.btn_item, CustomTheme.btn_pkmn, CustomTheme.btn_run }

    love.graphics.setColor(1, 1, 1, 1)
    if CustomTheme.main_menu_bg then
      drawCustomBg(CustomTheme.main_menu_bg, MENU_X, MENU_Y, MENU_W, MENU_H, "bottom-center")
    else
      drawMenuBox(MENU_X, MENU_Y, MENU_W, MENU_H)
    end

    local idx = math.max(1, math.min(4,
      battle.wideMenuIndex or nativeToVisual[battle.menuIndex or 1] or 1))

    -- Espaçamento reduzido de ~74 (MENU_W / 4) para 50 para deixar os botões mais juntos
    local step = 50 
    local groupCenter = MENU_X + MENU_W / 2
    local textY = MENU_Y + MENU_H / 2 - 4
    local imgY = MENU_Y + MENU_H / 2

    for i, text in ipairs(labels) do
      local cx = groupCenter + (i - 2.5) * step
      local selected = (i == idx and battle.phase == "menu" and not battle.safari and not battle.demo)
      local zoom = selected and 1.30 or 1.00 -- Zoom levemente ajustado para suportar assets mais largos
      
      local img = btn_imgs[i]
      if img then
        love.graphics.setColor(1, 1, 1, 1)
        local iw, ih = img:getDimensions()
        -- Tamanho reduzido em mais 15% em relação ao fator anterior (0.55 * 0.85 = 0.4675)
        local scaleFactor = 0.4675 * zoom
        love.graphics.draw(img, math.floor(cx), math.floor(imgY), 0, scaleFactor, scaleFactor, iw/2, ih/2)
      else
        drawCommandTextZoom(text, cx, textY, zoom)
      end
    end
  end

  local MOVE_TYPE_COLORS = {
    fire = { 0.88, 0.18, 0.12 }, water = { 0.18, 0.42, 0.88 }, flying = { 0.45, 0.72, 1.00 },
    poison = { 0.72, 0.45, 0.82 }, ground = { 0.88, 0.78, 0.52 }, rock = { 0.62, 0.48, 0.30 },
    bug = { 0.55, 0.82, 0.45 }, ghost = { 0.35, 0.18, 0.50 }, grass = { 0.20, 0.58, 0.28 },
    electric = { 0.95, 0.78, 0.12 }, psychic = { 0.90, 0.45, 0.66 }, ice = { 0.20, 0.82, 0.88 },
    dragon = { 0.48, 0.28, 0.78 }, dark = { 0.24, 0.16, 0.12 }, normal = { 0.62, 0.62, 0.62 },
    fighting = { 0.72, 0.24, 0.18 }, steel = { 0.48, 0.52, 0.58 }, fairy = { 0.92, 0.58, 0.78 },
  }

  local function moveTypeColor(typeName)
    local key = tostring(typeName or ""):lower():gsub("_type", "")
    return MOVE_TYPE_COLORS[key]
  end

  local MOVE_TAG_W = 63
  local MOVE_TAG_H = 13

  local function drawMoveTypeTag(typeName, cx, cy, scale, selected)
    if not typeName then return end
    local sc = scale or 1
    local w = (MOVE_TAG_W or 32) * sc
    local h = (MOVE_TAG_H or 12) * sc
    
    local key = tostring(typeName):lower():gsub("_type", "")
    local customImg = CustomTheme.types and CustomTheme.types[key]
    
    if customImg then
      love.graphics.setColor(1, 1, 1, 1)
      local iw, ih = customImg:getDimensions()
      love.graphics.draw(customImg, math.floor(cx), math.floor(cy), 0, w/iw, h/ih, iw/2, ih/2)
    else
      local x = cx - w / 2
      local y = cy - h / 2
      local c = type(moveTypeColor) == "function" and moveTypeColor(typeName)
      
      if c and type(c) == "table" and #c >= 3 then
        local rx = math.floor(x)
        local ry = math.floor(y)
        local radius = 3 * sc
        
        love.graphics.setColor(c[1] * 0.80, c[2] * 0.80, c[3] * 0.80, 0.85)
        love.graphics.rectangle("fill", rx, ry, w, h, radius, radius)
        
        love.graphics.setColor(c[1], c[2], c[3], 1)
        love.graphics.setLineWidth(1)
        love.graphics.rectangle("line", rx + 0.5, ry + 0.5, w - 1, h - 1, radius, radius)
      end
    end
  end

  -- Helpers para o Auto-Contraste em cima de Texturas de Tipos Individuais (Fix)
  local function getTypeLuminance(typeName)
    local key = tostring(typeName or ""):lower():gsub("_type", "")
    if CustomTheme.type_luminance and CustomTheme.type_luminance[key] then
      return CustomTheme.type_luminance[key]
    end
    local c = MOVE_TYPE_COLORS[key]
    if c then
      return (0.299 * c[1] + 0.587 * c[2] + 0.114 * c[3])
    end
    return 1.0 -- default light se nada der certo
  end

  local MOVE_DESCRIPTIONS = {
    ["Absorb"]="User recovers half the HP inflicted on opponent.",
    ["Acid"]="May lower opponent's Special Defense.",
    ["Acid Armor"]="Sharply raises user's Defense.",
    ["Agility"]="Sharply raises user's Speed.",
    ["Amnesia"]="Sharply raises user's Special Defense.",
    ["Aurora Beam"]="May lower opponent's Attack.",
    ["Barrage"]="Hits 2-5 times in one turn.",
    ["Barrier"]="Sharply raises user's Defense.",
    ["Bide"]="User takes damage for two turns then strikes back double.",
    ["Bind"]="Traps opponent, damaging them for 4-5 turns.",
    ["Bite"]="May cause flinching.",
    ["Blizzard"]="Deals damage and has a 10% chance of freezing the target.",
    ["Body Slam"]="Deals damage and has a 30% chance of paralyzing the target.",
    ["Bone Club"]="May cause flinching.",
    ["Bonemerang"]="Hits twice in one turn.",
    ["Bubble"]="May lower opponent's Speed.",
    ["Bubble Beam"]="May lower opponent's Speed.",
    ["Clamp"]="Traps opponent, damaging them for 4-5 turns.",
    ["Comet Punch"]="Hits 2-5 times in one turn.",
    ["Confuse Ray"]="Confuses opponent.",
    ["Confusion"]="May confuse opponent.",
    ["Constrict"]="May lower opponent's Speed by one stage.",
    ["Conversion"]="Changes user's type to that of its first move.",
    ["Counter"]="When hit by a Physical Attack, user strikes back with 2x power.",
    ["Crabhammer"]="High critical hit ratio.",
    ["Cut"]="Deals damage.",
    ["Defense Curl"]="Raises user's Defense.",
    ["Dig"]="Digs underground on first turn, attacks on second. Can also escape caves.",
    ["Disable"]="Opponent can't use its last attack for a few turns.",
    ["Dizzy Punch"]="May confuse opponent.",
    ["Double Kick"]="Hits twice in one turn.",
    ["Double Slap"]="Hits 2-5 times in one turn.",
    ["Double Team"]="Raises user's Evasiveness.",
    ["Double-Edge"]="User receives recoil damage.",
    ["Dragon Rage"]="Always inflicts 40 HP.",
    ["Dream Eater"]="User recovers half the HP inflicted on a sleeping opponent.",
    ["Drill Peck"]="Deals damage.",
    ["Earthquake"]="Power is doubled if opponent is underground from using Dig.",
    ["Egg Bomb"]="Deals damage.",
    ["Ember"]="Deals damage and has a 10% chance of burning the target.",
    ["Explosion"]="User faints.",
    ["Fire Blast"]="Deals damage and has a 10% chance of burning the target.",
    ["Fire Punch"]="May burn opponent.",
    ["Fire Spin"]="Traps opponent, damaging them for 4-5 turns.",
    ["Fissure"]="One-Hit-KO, if it hits.",
    ["Flamethrower"]="Deals damage and has a 10% chance of burning the target.",
    ["Flash"]="Lowers opponent's Accuracy.",
    ["Fly"]="Flies up on first turn, attacks on second turn.",
    ["Focus Energy"]="Increases critical hit ratio.",
    ["Fury Attack"]="Hits 2-5 times in one turn.",
    ["Fury Swipes"]="Hits 2-5 times in one turn.",
    ["Glare"]="Paralyzes opponent.",
    ["Growl"]="Lowers opponent's Attack.",
    ["Growth"]="Raises user's Attack and Special Attack.",
    ["Guillotine"]="One-Hit-KO, if it hits.",
    ["Harden"]="Raises user's Defense.",
    ["Haze"]="Resets all stat changes.",
    ["Headbutt"]="May cause flinching.",
    ["High Jump Kick"]="If it misses, the user loses half their HP.",
    ["Horn Attack"]="Deals damage.",
    ["Horn Drill"]="One-Hit-KO, if it hits.",
    ["Hydro Pump"]="Deals damage.",
    ["Hyper Beam"]="User must recharge next turn.",
    ["Hyper Fang"]="May cause flinching.",
    ["Hypnosis"]="Puts opponent to sleep.",
    ["Ice Beam"]="Deals damage and has a 10% chance of freezing the target.",
    ["Ice Punch"]="May freeze opponent.",
    ["Jump Kick"]="If it misses, the user loses half their HP.",
    ["Karate Chop"]="High critical hit ratio.",
    ["Kinesis"]="Lowers opponent's Accuracy.",
    ["Leech Life"]="User recovers half the HP inflicted on opponent.",
    ["Leech Seed"]="Drains HP from opponent each turn.",
    ["Leer"]="Lowers opponent's Defense.",
    ["Light Screen"]="Halves damage from Special attacks for 5 turns.",
    ["Lovely Kiss"]="Puts opponent to sleep.",
    ["Low Kick"]="The heavier the opponent, the stronger the attack.",
    ["Meditate"]="Raises user's Attack.",
    ["Mega Drain"]="User recovers half the HP inflicted on opponent.",
    ["Mega Kick"]="Deals damage.",
    ["Mega Punch"]="Deals damage.",
    ["Metronome"]="User performs almost any move in the game at random.",
    ["Mimic"]="Copies the opponent's last move.",
    ["Minimize"]="Sharply raises user's Evasiveness.",
    ["Mirror Move"]="User performs the opponent's last move.",
    ["Mist"]="User's stats cannot be changed for a period of time.",
    ["Night Shade"]="Inflicts damage equal to user's level.",
    ["Pay Day"]="Money is earned after the battle.",
    ["Peck"]="Deals damage.",
    ["Petal Dance"]="User attacks for 2-3 turns but then becomes confused.",
    ["Pin Missile"]="Hits 2-5 times in one turn.",
    ["Poison Gas"]="Poisons opponent.",
    ["Poison Powder"]="Poisons opponent.",
    ["Poison Sting"]="Deals damage and has a 30% chance of poisoning the target.",
    ["Pound"]="Deals damage.",
    ["Psybeam"]="May confuse opponent.",
    ["Psychic"]="May lower opponent's Special Defense.",
    ["Psywave"]="Inflicts damage 50-150% of user's level.",
    ["Quick Attack"]="User attacks first.",
    ["Rage"]="Raises user's Attack when hit.",
    ["Razor Leaf"]="High critical hit ratio.",
    ["Razor Wind"]="Charges on first turn, attacks on second. High critical hit ratio.",
    ["Recover"]="User recovers half its max HP.",
    ["Reflect"]="Halves damage from Physical attacks for 5 turns.",
    ["Rest"]="User sleeps for 2 turns, but user is fully healed.",
    ["Roar"]="In battles, the opponent switches. In the wild, the Pokémon runs.",
    ["Rock Slide"]="May cause flinching.",
    ["Rock Throw"]="Deals damage.",
    ["Rolling Kick"]="May cause flinching.",
    ["Sand Attack"]="Lowers opponent's Accuracy.",
    ["Scratch"]="Deals damage.",
    ["Screech"]="Sharply lowers opponent's Defense.",
    ["Seismic Toss"]="Inflicts damage equal to user's level.",
    ["Self-Destruct"]="User faints.",
    ["Sharpen"]="Raises user's Attack.",
    ["Sing"]="Puts opponent to sleep.",
    ["Skull Bash"]="Raises Defense on first turn, attacks on second.",
    ["Sky Attack"]="Charges on first turn, attacks on second. May cause flinching. High critical hit ratio.",
    ["Slam"]="Deals damage.",
    ["Slash"]="High critical hit ratio.",
    ["Sleep Powder"]="Puts opponent to sleep.",
    ["Sludge"]="May poison opponent.",
    ["Smog"]="Deals damage and has a 40% chance of poisoning the target.",
    ["Smokescreen"]="Lowers opponent's Accuracy.",
    ["Soft-Boiled"]="User recovers half its max HP.",
    ["Solar Beam"]="Charges on first turn, attacks on second.",
    ["Sonic Boom"]="Always inflicts 20 HP.",
    ["Spike Cannon"]="Hits 2-5 times in one turn.",
    ["Splash"]="Doesn't do ANYTHING.",
    ["Spore"]="Puts opponent to sleep.",
    ["Stomp"]="May cause flinching.",
    ["Strength"]="Deals damage.",
    ["String Shot"]="Sharply lowers opponent's Speed.",
    ["Struggle"]="Only usable when all PP are gone. Hurts the user.",
    ["Stun Spore"]="Paralyzes the target.",
    ["Submission"]="User receives recoil damage.",
    ["Substitute"]="Uses HP to create a decoy that takes hits.",
    ["Super Fang"]="Always takes off half of the opponent's HP.",
    ["Supersonic"]="Confuses opponent.",
    ["Surf"]="Hits all adjacent Pokémon.",
    ["Swift"]="Ignores Accuracy and Evasiveness.",
    ["Swords Dance"]="Sharply raises user's Attack.",
    ["Tackle"]="Deals damage.",
    ["Tail Whip"]="Lowers opponent's Defense.",
    ["Take Down"]="User receives recoil damage.",
    ["Teleport"]="Allows user to flee wild battles; also warps player to last PokéCenter.",
    ["Thrash"]="User attacks for 2-3 turns but then becomes confused.",
    ["Thunder"]="Deals damage and has a 10% chance of paralyzing the target.",
    ["Thunder Punch"]="May paralyze opponent.",
    ["Thunder Shock"]="Deals damage and has a 10% chance of paralyzing the target.",
    ["Thunder Wave"]="Paralyzes opponent.",
    ["Thunderbolt"]="Deals damage and has a 10% chance of paralyzing the target.",
    ["Toxic"]="Badly poisons opponent.",
    ["Transform"]="User takes on the form and attacks of the opponent.",
    ["Tri Attack"]="May paralyze, burn or freeze opponent.",
    ["Twineedle"]="Hits twice in one turn. May poison opponent.",
    ["Vine Whip"]="Deals damage.",
    ["Vise Grip"]="Deals damage.",
    ["Water Gun"]="Deals damage.",
    ["Waterfall"]="May cause flinching.",
    ["Whirlwind"]="In battles, the opponent switches. In the wild, the Pokémon runs.",
    ["Wing Attack"]="Deals damage.",
    ["Withdraw"]="Raises user's Defense.",
    ["Wrap"]="Traps opponent, damaging them for 4-5 turns.",
  }

  local function normalizeMoveKey(v)
    return tostring(v or ""):lower():gsub("[_%-]", " "):gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
  end

  local MOVE_DESCRIPTIONS_NORMALIZED = {}
  for k, v in pairs(MOVE_DESCRIPTIONS) do
    MOVE_DESCRIPTIONS_NORMALIZED[normalizeMoveKey(k)] = v
  end

  local function moveDescription(def, moveId)
    if not def and not moveId then return "" end
    local candidates = {
      def and def.name, def and def.label, def and def.id, moveId,
    }
    for _, candidate in ipairs(candidates) do
      local d = MOVE_DESCRIPTIONS_NORMALIZED[normalizeMoveKey(candidate)]
      if d then return d end
    end
    local fields = { "description", "desc", "shortDescription", "effectText", "effect" }
    for _, field in ipairs(fields) do
      local d = def and def[field]
      if type(d) == "string" and d ~= "" then return d end
    end
    return "Deals damage."
  end

  local function drawDescriptionLine(text, cx, y, scale)
    drawCenteredText(tostring(text or ""), cx, y, scale or 0.44)
  end

  local function getMoveDescriptionLines(text)
    text = tostring(text or "")
    local maxChars = 24
    local words = {}
    for word in text:gmatch("%S+") do words[#words + 1] = word end
    local lines = {}
    local line = ""
    for _, word in ipairs(words) do
      local candidate = (line == "") and word or (line .. " " .. word)
      if #candidate <= maxChars then
        line = candidate
      else
        if line ~= "" then lines[#lines + 1] = line end
        line = word
      end
    end
    if line ~= "" then lines[#lines + 1] = line end
    if #lines == 0 then lines[1] = "" end

    if #lines > 4 then
      local merged = lines[4]
      for i = 5, #lines do merged = merged .. " " .. lines[i] end
      lines[4] = merged
      while #lines > 4 do table.remove(lines) end
      if #lines[4] > maxChars then
        lines[4] = lines[4]:sub(1, maxChars - 1) .. "…"
      end
    end
    return lines
  end

  local function drawMoveMenu(battle)
    local ww, wh = love.graphics.getDimensions()
    local isPortrait = (ww < wh)

    if isPortrait then
      -- MODO RETRATO: Empilha a caixa de Golpes e a caixa de Descrição/PP verticalmente
      local topBoxY = MENU_Y
      local topBoxH = 85
      local botBoxY = MENU_Y + topBoxH + 6
      local botBoxH = 95
      local fullW = MENU_W

      love.graphics.setColor(1, 1, 1, 1)
      if CustomTheme.moves_left_bg then
        drawCustomBg(CustomTheme.moves_left_bg, MENU_X, topBoxY, fullW, topBoxH, "stretch")
      else
        drawMenuBox(MENU_X, topBoxY, fullW, topBoxH)
      end

      love.graphics.setColor(1, 1, 1, 1)
      if CustomTheme.moves_right_bg then
        drawCustomBg(CustomTheme.moves_right_bg, MENU_X, botBoxY, fullW, botBoxH, "stretch")
      else
        drawMenuBox(MENU_X, botBoxY, fullW, botBoxH)
      end

      -- Centralização matemática absoluta em relação ao MENU_W (fullW) e topBoxH
      local baseTagScale = 1.30
      local scaledTagW = MOVE_TAG_W * baseTagScale
      local scaledTagH = MOVE_TAG_H * baseTagScale
      local moveGapX, moveGapY = 16, 11.4
      
      local centers = {
        MENU_X + (fullW / 2) - (scaledTagW / 2) - (moveGapX / 2),
        MENU_X + (fullW / 2) + (scaledTagW / 2) + (moveGapX / 2)
      }
      local rows = {
        topBoxY + (topBoxH / 2) - (scaledTagH / 2) - (moveGapY / 2),
        topBoxY + (topBoxH / 2) + (scaledTagH / 2) + (moveGapY / 2)
      }

      for i = 1, 4 do
        local mv = battle.player and battle.player.curMoves and battle.player.curMoves[i]
        local name = "-"
        local def = nil
        if mv then
          def = battle.data.moves[mv.id]
          name = def and def.name or tostring(mv.id)
        end
        local selected = (i == math.max(1, math.min(4, battle.moveIndex or 1)))
        local stateZoom = selected and 1.15 or 1.00
        local finalZoom = baseTagScale * stateZoom
        local sc = #name > 10 and 0.85 or 0.95
        local center = centers[((i - 1) % 2) + 1]
        local rowY = rows[math.floor((i - 1) / 2) + 1]
        local typeName = def and def.type and TypeChart.displayName(def.type) or ""
        local typeLum = 1.0
        
        if typeName ~= "" then
          drawMoveTypeTag(typeName, center, rowY, finalZoom, selected)
          typeLum = getTypeLuminance(typeName)
        end
        
        -- Auto Contraste individual do Move baseado no Asset da tipagem
        local txtColor = nil
        local okColor, valColor = pcall(mod.options.get, mod.options, "text_color")
        if (not okColor or valColor == "auto") and typeName ~= "" then
           txtColor = (typeLum < 0.55) and {1, 1, 1, 1} or {0, 0, 0, 1}
        end
        
        drawCenteredTextZoom(name, center, rowY, sc, finalZoom, txtColor)
      end

      -- Descrição e PP na caixa inferior (com fontes maiores e mais espaçadas)
      local mi = math.max(1, math.min(4, battle.moveIndex or 1))
      local sel = battle.player and battle.player.curMoves and battle.player.curMoves[mi]
      local def = sel and battle.data.moves[sel.id]
      if sel and def then
        local typeName = def.type and TypeChart.displayName(def.type) or ""
        local maxPP = def.pp + (sel.ppUps or 0) * math.floor(def.pp / 5)
        local cx = MENU_X + fullW / 2

        local descLines = getMoveDescriptionLines(moveDescription(def, sel.id))
        local lineStep = 16
        local descStartY = botBoxY + 14
        for i, lineText in ipairs(descLines) do
          if i <= 4 then
            drawDescriptionLine(lineText, cx, descStartY + (i - 1) * lineStep, 0.85)
          end
        end

        local typeY = botBoxY + botBoxH - 18
        local typeScale = 0.95
        local ppText = "PP " .. tostring(sel.pp) .. "/" .. tostring(maxPP)
        local typeW = width(typeName) * typeScale
        local ppW = width(ppText) * typeScale
        local sideGap = 60
        local totalW = typeW + sideGap + ppW
        local gx = cx - totalW / 2

        drawText(typeName, gx, typeY, typeScale)
        drawText(ppText, gx + typeW + sideGap, typeY, typeScale)
      end

    else
      -- MODO PAISAGEM (Padrão lado a lado mantido intacto)
      love.graphics.setColor(1, 1, 1, 1)
      if CustomTheme.moves_left_bg then
        drawCustomBg(CustomTheme.moves_left_bg, MENU_X, MENU_Y, MOVE_LEFT_W, MENU_H, "bottom-left")
      else
        drawMenuBox(MENU_X, MENU_Y, MOVE_LEFT_W, MENU_H)
      end

      love.graphics.setColor(1, 1, 1, 1)
      if CustomTheme.moves_right_bg then
        drawCustomBg(CustomTheme.moves_right_bg, MOVE_RIGHT_X, MENU_Y, MOVE_RIGHT_W, MENU_H, "bottom-right")
      else
        drawMenuBox(MOVE_RIGHT_X, MENU_Y, MOVE_RIGHT_W, MENU_H)
      end

      -- Centralização matemática absoluta do grupo 2x2 em relação à MOVE_LEFT_W e MENU_H
      local moveGapX, moveGapY = 12, 5.7
      local centers = {
        MENU_X + (MOVE_LEFT_W / 2) - (MOVE_TAG_W / 2) - (moveGapX / 2),
        MENU_X + (MOVE_LEFT_W / 2) + (MOVE_TAG_W / 2) + (moveGapX / 2)
      }
      local rows = {
        MENU_Y + (MENU_H / 2) - (MOVE_TAG_H / 2) - (moveGapY / 2),
        MENU_Y + (MENU_H / 2) + (MOVE_TAG_H / 2) + (moveGapY / 2)
      }

      for i = 1, 4 do
        local mv = battle.player and battle.player.curMoves and battle.player.curMoves[i]
        local name = "-"
        local def = nil
        if mv then
          def = battle.data.moves[mv.id]
          name = def and def.name or tostring(mv.id)
        end
        local sc = #name > 10 and 0.54 or 0.64
        local center = centers[((i - 1) % 2) + 1]
        local rowY = rows[math.floor((i - 1) / 2) + 1]
        local typeName = def and def.type and TypeChart.displayName(def.type) or ""
        local selected = (i == math.max(1, math.min(4, battle.moveIndex or 1)))
        local zoom = selected and 1.10 or 1.00
        local typeLum = 1.0
        
        if typeName ~= "" then
          drawMoveTypeTag(typeName, center, rowY, zoom, selected)
          typeLum = getTypeLuminance(typeName)
        end
        
        -- Auto Contraste individual do Move
        local txtColor = nil
        local okColor, valColor = pcall(mod.options.get, mod.options, "text_color")
        if (not okColor or valColor == "auto") and typeName ~= "" then
           txtColor = (typeLum < 0.55) and {1, 1, 1, 1} or {0, 0, 0, 1}
        end
        
        drawCenteredTextZoom(name, center, rowY, sc, zoom, txtColor)
      end
      
      local mi = math.max(1, math.min(4, battle.moveIndex or 1))
      local sel = battle.player and battle.player.curMoves and battle.player.curMoves[mi]
      local def = sel and battle.data.moves[sel.id]
      if sel and def then
        local typeName = def.type and TypeChart.displayName(def.type) or ""
        local maxPP = def.pp + (sel.ppUps or 0) * math.floor(def.pp / 5)
        local cx = MOVE_RIGHT_X + MOVE_RIGHT_W / 2
        
        local descLines = getMoveDescriptionLines(moveDescription(def, sel.id))
        local lineStep = 6
        local typeScale = 0.56
        
        local rightStartY = MENU_Y + 9
        for i, lineText in ipairs(descLines) do
          drawDescriptionLine(lineText, cx, rightStartY + (i - 1) * lineStep, 0.44)
        end
        
        local typeY = MENU_Y + MENU_H - 14
        local ppText = "PP " .. tostring(sel.pp) .. "/" .. tostring(maxPP)
        local typeW = width(typeName) * typeScale
        local ppW = width(ppText) * typeScale
        local sideGap = 10
        local totalW = typeW + sideGap + ppW
        local gx = cx - totalW / 2
        
        drawText(typeName, gx, typeY, typeScale)
        drawText(ppText, gx + typeW + sideGap, typeY, typeScale)
      end
    end
  end

  local drawMessagePokeball

  local function drawMessageBox(battle)
    love.graphics.setColor(1, 1, 1, 1)
    if CustomTheme.message_bg then
      drawCustomBg(CustomTheme.message_bg, MENU_X, MENU_Y, MENU_W, MENU_H, "bottom-center")
    else
      drawMenuBox(MENU_X, MENU_Y, MENU_W, MENU_H)
    end
    if not ((battle.current or battle.animPlaying or battle.msgHold) and battle.shown) then return end
    local messageScale = 0.82 * bottomMessageFontMultiplier()
    local messageStep = 9 * bottomMessageFontMultiplier()
    local count = math.min(2, #battle.shown)
    local totalH = count * messageStep
    local firstY = MENU_Y + (MENU_H - totalH) / 2
    for li, line in ipairs(battle.shown) do
      if li > 2 then break end
      drawCodeLineScaled(line, MENU_X + 12, firstY + (li - 1) * messageStep, messageScale)
    end
    if (battle.msgWaiting or battle.msgPrompt) and battle.frame % 60 < 30 then
      drawMessagePokeball(MENU_X + MENU_W - 10, MENU_Y + 32)
    end
  end

  local partyPokeballImage = nil

  local function makePartyPokeball()
    if partyPokeballImage then return partyPokeballImage end
    local size = 16
    local data = love.image.newImageData(size, size)
    local c = (size - 1) / 2
    local r = 7.2
    for py = 0, size - 1 do
      for px = 0, size - 1 do
        local dx, dy = px - c, py - c
        local inside = dx * dx + dy * dy <= r * r
        if inside then
          local d = math.sqrt(dx * dx + dy * dy)
          if d >= r - 1.0 then
            data:setPixel(px, py, 0, 0, 0, 1)
          elseif math.abs(dy) < 1.0 then
            data:setPixel(px, py, 0, 0, 0, 1)
          elseif dy < 0 then
            data:setPixel(px, py, 0.88, 0.05, 0.05, 1)
          else
            data:setPixel(px, py, 1, 1, 1, 1)
          end
        else
          data:setPixel(px, py, 0, 0, 0, 0)
        end
      end
    end
    for py = 5, 10 do
      for px = 5, 10 do
        local dx, dy = px - c, py - c
        local d = math.sqrt(dx * dx + dy * dy)
        if d <= 3.0 then
          if d >= 2.0 then
            data:setPixel(px, py, 0, 0, 0, 1)
          else
            data:setPixel(px, py, 1, 1, 1, 1)
          end
        end
      end
    end
    partyPokeballImage = love.graphics.newImage(data)
    partyPokeballImage:setFilter("nearest", "nearest")
    return partyPokeballImage
  end

  local function drawPokeballIndicator(x, y)
    local img = makePartyPokeball()
    local scale = BALL_SIZE / 16
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.draw(img, x, y, 0, scale, scale, 0, 0)
  end

  drawMessagePokeball = function(cx, cy)
    local img = makePartyPokeball()
    local size = 8
    local scale = size / 16
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.draw(img, math.floor(cx + 0.5), math.floor(cy + 0.5),
      0, scale, scale, 8, 8)
  end

  local function drawPartyPokeballIndicator(cx, cy, frame)
    local img = makePartyPokeball()
    local t = love.timer.getTime()
    local rotationPeriod = 22.5
    local angle = (t % rotationPeriod) * (2 * math.pi / rotationPeriod)
    local scale = PARTY_BALL_SIZE / 16
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.draw(img, math.floor(cx + 0.5), math.floor(cy + 0.5),
      angle, scale, scale, 8, 8)
  end

  local function panel(battler, x, y, side, battle)
    if not battler or not battler.mon then return end
    local name = tostring(battler.name or "")
    local lv = "Lv:" .. tostring(battler.mon.level or 0)
    local cur, max = hp(battler)
    local s = TEXT_SCALE
    local innerLeft, innerRight = x + INNER, x + PANEL_W - INNER
    local line1 = y + INFO_TOP
    local line2 = line1 + INFO_STEP
    local line3 = line2 + INFO_STEP
    local line4 = line3 + INFO_STEP

    love.graphics.setColor(1, 1, 1, 1)
    if side == "left" and CustomTheme.enemy_top_bg then
        drawCustomBg(CustomTheme.enemy_top_bg, x, y, PANEL_W, PANEL_H, "top-left")
    elseif side == "right" and CustomTheme.player_top_bg then
        drawCustomBg(CustomTheme.player_top_bg, x, y, PANEL_W, PANEL_H, "top-right")
    else
        fillPanel(x, y, PANEL_W, PANEL_H, side)
        frame(x, y, PANEL_W, PANEL_H, side)
    end

    local nameW, lvW = width(name) * s, width(lv) * s
    if side == "left" then
      drawText(name, innerLeft, line1, s)
      drawText(lv, innerLeft, line2, s)
      local hpLabelW = width("HP:") * s
      drawText("HP:", innerLeft, line3, s)
      drawBar(innerLeft + hpLabelW + 2, line3, cur, max)
      local showCaught = battle and battle.kind == "wild"
        and battle.enemy and battle.enemy.mon
        and battle.game and battle.game.save and battle.game.save.pokedex
        and battle.game.save.pokedex.owned
        and battle.game.save.pokedex.owned[battle.enemy.mon.species]
      if showCaught then drawPokeballIndicator(innerLeft, line4 - 1) end
    else
      drawText(name, innerRight - nameW, line1, s)
      drawText(lv, innerRight - lvW, line2, s)
      local hpLabelW = width("HP:") * s
      local groupW = hpLabelW + 2 + BAR_W
      local groupX = innerRight - groupW
      drawText("HP:", groupX, line3, s)
      drawBar(groupX + hpLabelW + 2, line3, cur, max)
      local t = tostring(cur) .. "/" .. tostring(max)
      drawText(t, innerRight - width(t) * s, line4, s)
    end
  end

  local textBoxBelongsToWideBattle

  local function statusVisible(battle)
    if not battle then return false end
    if battle.safari or battle.demo then return false end
    if battle.phase == "intro" or battle.phase == "transition" or battle.phase == "outro" then 
      return false 
    end
    return true
  end

  local function findBattleTextBox(states, battleIndex)
    if not states or not battleIndex then return nil end
    for i = #states, battleIndex + 1, -1 do
      local st = states[i]
      if st and st.isTextBox then return st end
    end
    return nil
  end
  
  local function screenIsBattleOverlay(state, id)
    if not (state and activeBattle) then return false end
    if id == "BagMenu" then
      return state.screenId == "BagMenu" or state.kind == "bag" or state.listKind == "bag"
    elseif id == "PartyMenu" then
      return (state.screenId == "PartyMenu" or state.__screenId == "PartyMenu")
        and (state.battle == activeBattle or state.battle == nil and state.party ~= nil)
    elseif id == "SummaryMenu" then
      return state.screenId == "SummaryMenu"
    elseif id == "ChoiceBox" then
      return state.screenId == "ChoiceBox"
        or (state.index ~= nil and state.onChoose ~= nil
            and state.labels ~= nil)
        or (state.index ~= nil and state.onChoose ~= nil
            and state.tx ~= nil and state.ty ~= nil)
    elseif id == "TextBox" then
      return textBoxBelongsToWideBattle(state)
    end
    return false
  end

  local function drawWideCard(x, y, w, h)
    drawMenuBox(x, y, w, h)
  end

  local function drawNativePartyScreen(state, game)
    local x, y, w, h = PARTY_X, PARTY_Y, PARTY_W, PARTY_H
    love.graphics.setColor(1, 1, 1, 1)
    if CustomTheme.party_bg then
      drawCustomBg(CustomTheme.party_bg, x, y, w, h, "bottom-center")
    else
      drawWideCard(x, y, w, h)
    end

    local party = state.party or (game.save and game.save.party) or {}
    local PartyMenu = require("src.ui.PartyMenu")
    local Theme = require("src.ui.Theme")

    -- Gap horizontal reduzido em 25% (de 8 para 6)
    local colGap = 6
    local colW = math.floor((w - 14 - colGap) / 2)
    local slotH = 25
    local rowStep = 30
    
    -- Centralização vertical conjunta (6 retângulos + mensagem)
    local blockTotalH = 94
    local innerX = x + 7
    local innerY = y + math.floor((h - blockTotalH) / 2)
    local messageY = innerY + 89

    local function drawEntry(i, mon)
      local col = (i - 1) % 2
      local row = math.floor((i - 1) / 2)
      local px = innerX + col * (colW + colGap)
      local py = innerY + row * rowStep
      local selected = (i == (state.index or 1))

      local inset = colW * 0.05
      local rectX = px + inset
      local rectW = colW - (inset * 2)

      love.graphics.setColor(1, 1, 1, 1)
      if CustomTheme.party_slot_bg then
        drawCustomBg(CustomTheme.party_slot_bg, rectX, py, rectW, slotH, "stretch")
      else
        love.graphics.setColor(getBoxFillColor())
        love.graphics.rectangle("fill", rectX, py, rectW, slotH)
        love.graphics.setColor(getTextColor())
        love.graphics.setLineWidth(1)
        love.graphics.rectangle("line", rectX, py, rectW, slotH)
      end

      if not mon then return end

      local iconW = 16
      -- Gap entre sprite e informações aumentado em 20% (de 8 para 9.6)
      local infoGap = 9.6
      local infoW = 72
      local blockW = iconW + infoGap + infoW
      local blockH = 20
      local bx = px + (colW - blockW) / 2
      local by = py + (slotH - blockH) / 2
      local infoX = bx + iconW + infoGap

      love.graphics.setColor(1, 1, 1, 1)
      local iconY = by - 12
      PartyMenu.drawIcon(game, mon, math.floor(bx + 0.5),
        math.floor(iconY + 0.5), selected, state.blink or 0)

      local def = game.data.pokemon[mon.species]
      local name = mon.nickname or (def and def.name) or mon.species or "POKéMON"
      drawText(name, infoX, by, 0.56)
      drawText("Lv:" .. tostring(mon.level or 0), infoX, by + 7, 0.50)

      local hpCur = math.max(0, math.floor(mon.hp or 0))
      local hpMax = math.max(1, math.floor((mon.stats and mon.stats.hp) or 1))
      local hpText = ("%d/%d"):format(hpCur, hpMax)
      local hpScale = 0.45
      local hpTextW = width(hpText) * hpScale
      drawText(hpText, infoX, by + 14, hpScale)

      local barX = infoX + hpTextW + 4
      local barW = math.max(24, bx + blockW - barX)
      love.graphics.setColor(0, 0, 0, 1)
      love.graphics.rectangle("fill", math.floor(barX + 0.5),
        math.floor(by + 14.5), math.floor(barW + 0.5), 4)
      if hpCur > 0 then
        local r, g, b = hpColor(hpCur, hpMax)
        love.graphics.setColor(r, g, b, 1)
        love.graphics.rectangle("fill", math.floor(barX + 1.5),
          math.floor(by + 15.5),
          math.max(0, math.floor((barW - 2) * math.min(1, hpCur / hpMax))), 2)
      end

      if selected then
        drawPartyPokeballIndicator(rectX, py + math.floor(slotH / 2), state.blink or 0)
      end
    end

    for i = 1, 6 do drawEntry(i, party[i]) end

    local msg = state:bottomMessage()
    if msg then
      local oneLine = tostring(msg):gsub("\n", " ")
      drawCenteredText(oneLine, x + w / 2, messageY, 0.50)
    end

    if state.submenu and state.subItems then
      local n = #state.subItems
      local boxW = 94
      local boxH = n * 13 + 6
      local bx = x + w - boxW - 8
      local messageH = 10
      local by = y + h - boxH - messageH - 8
      love.graphics.setColor(getBoxFillColor())
      love.graphics.rectangle("fill", bx, by, boxW, boxH)
      love.graphics.setColor(getTextColor())
      love.graphics.rectangle("line", bx, by, boxW, boxH)
      for si, entry in ipairs(state.subItems) do
        drawText(entry.label, bx + 15, by + 4 + (si - 1) * 13, 0.56)
      end
      love.graphics.setColor(getTextColor())
      Font.drawCode(Theme.cursor, bx + 5,
        by + 4 + ((state.subIndex or 1) - 1) * 13)
    end

    love.graphics.setColor(1, 1, 1, 1)
  end

  local function bagCategory(game, item)
    local id = item and item.value
    if not id then return "other" end
    local ItemEffects = require("src.inventory.ItemEffects")
    local def = game.data.items[id]
    if ItemEffects.isBattleMedicine(id) or ItemEffects.isBall(id)
       or id == "X_ATTACK" or id == "X_DEFEND" or id == "X_SPEED"
       or id == "X_SPECIAL" or id == "X_ACCURACY"
       or id == "DIRE_HIT" or id == "GUARD_SPEC" or id == "POKE_DOLL"
       or id == "POKE_FLUTE" then
      return "usable"
    end
    return "other"
  end

  local function buildBattleBagItems(game)
    local Bag = require("src.inventory.Bag")
    local out = {}
    for _, id in ipairs(Bag.order(game.save)) do
      local def = game.data.items[id]
      out[#out + 1] = {
        value = id,
        label = def and def.name or id,
        right = (def and not def.keyItem and not tostring(id):find("^HM_"))
          and ("x" .. tostring(game.save.inventory[id] or 0)) or nil,
      }
    end
    out[#out + 1] = { cancel = true, label = Strings("CANCEL") }
    return out
  end

  local function rebuildBagCategory(state, game)
    if not state or state.kind ~= "bag" then return end
    local all = buildBattleBagItems(game)
    state.wideAllItems = all
    local wanted = state.wideBagTab or 1
    local out = {}
    for _, item in ipairs(all) do
      if item.cancel
         or (wanted == 1 and bagCategory(game, item) == "usable")
         or (wanted == 2 and bagCategory(game, item) == "other") then
        out[#out + 1] = item
      end
    end
    state.items = out
    state.index = math.max(1, math.min(state.index or 1, #out > 0 and #out or 1))
    state.scroll = math.max(0, math.min(state.scroll or 0,
      math.max(0, #out - (state.cursorRows or 3))))
  end

  local function drawBagScreen(state, game)
    local x, y, w, h = BAG_X, BAG_Y, BAG_W, BAG_H
    love.graphics.setColor(1, 1, 1, 1)
    if CustomTheme.bag_bg then
      drawCustomBg(CustomTheme.bag_bg, x, y, w, h, "bottom-center")
    else
      drawWideCard(x, y, w, h)
    end
    drawCenteredText("ITEMS", x + w / 2, y + 12, 0.78)
    local tabW = 92
    drawCenteredText("USE", x + w / 2 - 58, y + 26, 0.60)
    drawCenteredText("OTHER", x + w / 2 + 58, y + 26, 0.60)
    love.graphics.setColor(getTextColor())
    local tabCx = state.wideBagTab == 2 and (x + w / 2 + 58) or (x + w / 2 - 58)
    love.graphics.rectangle("fill", math.floor(tabCx - 36), y + 39, 72, 1)

    local items = state.items or {}
    local rows = math.min(4, #items)
    local start = math.max(1, (state.index or 1) - math.floor((rows - 1) / 2))
    start = math.min(start, math.max(1, #items - rows + 1))
    local rowH = 13
    local listY = y + 47
    for n = 1, rows do
      local i = start + n - 1
      local row = items[i]
      if row then
        local ry = listY + (n - 1) * rowH
        if i == state.index then
          love.graphics.setColor(getTextColor())
          local tCY = ry + 2.5 
          love.graphics.polygon("fill", x + 9, tCY - 3, x + 15, tCY, x + 9, tCY + 3)
        end
        drawText(row.label or row.value or "", x + 19, ry, 0.64)
        if row.right then
          drawText(row.right, x + w - 12 - width(row.right) * 0.64, ry, 0.64)
        end
      end
    end
    if #items == 0 then drawCenteredText("NO ITEMS", x + w / 2, y + 61, 0.72) end
  end

  local summarySpriteCache = setmetatable({}, { __mode = "k" })

  local function resolveSummarySprite(state, game, mon)
    if state and state.sprite then return state.sprite end
    if not mon then return nil end
    if summarySpriteCache[mon] then return summarySpriteCache[mon] end

    local ok, SummaryMenu = pcall(require, "src.ui.SummaryMenu")
    if ok and SummaryMenu and SummaryMenu.new then
      local made, native = pcall(SummaryMenu.new, game, mon)
      if made and native and native.sprite then
        summarySpriteCache[mon] = native.sprite
        return native.sprite
      end
    end
    return nil
  end

  local function drawSummaryScreen(state, game)
    local x, y, w, h = SUMMARY_X, SUMMARY_Y, SUMMARY_W, SUMMARY_H
    love.graphics.setColor(1, 1, 1, 1)
    if CustomTheme.summary_bg then
      drawCustomBg(CustomTheme.summary_bg, x, y, w, h, "bottom-center")
    else
      drawWideCard(x, y, w, h)
    end
    local mon = state.mon
    if not mon then return end
    local def = game.data.pokemon[mon.species]
    drawCenteredText("POKéMON", x + w / 2, y + 7, 0.72)

    local summarySprite = resolveSummarySprite(state, game, mon)
    if summarySprite then
      local pw, ph = summarySprite:getDimensions()
      local sx = x + 18
      local sy = (y + 63) - ph 
      love.graphics.setColor(1, 1, 1, 1)
      love.graphics.draw(summarySprite, sx, sy)
    end
    
    local ix = x + 76
    drawText(mon.nickname or def.name, ix, y + 29, 0.68)
    drawText("Lv:" .. tostring(mon.level or 0), ix, y + 41, 0.62)
    
    local hpString = ("HP: %d/%d"):format(mon.hp or 0, mon.stats and mon.stats.hp or 1)
    drawText(hpString, ix, y + 53, 0.58)
    drawBar(ix, y + 63, mon.hp or 0, mon.stats and mon.stats.hp or 1, 92)
    
    if state.page == 1 then
      drawText("ATTACK", x + 12, y + 74, 0.58)
      drawText(tostring(mon.stats.attack), x + 70, y + 74, 0.58)
      drawText("DEFENSE", x + 12, y + 84, 0.58)
      drawText(tostring(mon.stats.defense), x + 70, y + 84, 0.58)
      drawText("SPEED", x + 12, y + 94, 0.58)
      drawText(tostring(mon.stats.speed), x + 70, y + 94, 0.58)
      drawText("SPECIAL", x + 112, y + 74, 0.58)
      drawText(tostring(mon.stats.special), x + 170, y + 74, 0.58)
      drawText("TYPE", x + 112, y + 87, 0.58)
      drawText(TypeChart.displayName(def.types[1] or ""), x + 170, y + 87, 0.58)
    else
      drawText("EXP", x + 12, y + 75, 0.58)
      drawText(tostring(mon.exp or 0), x + 50, y + 75, 0.58)
      for i = 1, 4 do
        local mv = mon.moves[i]
        if mv then
          local md = game.data.moves[mv.id]
          drawText(md and md.name or mv.id, x + 12, y + 75 + i * 8, 0.54)
          drawText(("%d/%d"):format(mv.pp, md and md.pp or mv.pp), x + 176, y + 75 + i * 8, 0.54)
        end
      end
    end
  end

  local function drawChoiceOverlay(state, game)
    local x, y, w, h = 108, 66, 84, 40
    drawMenuBox(x, y, w, h)
    local labels = state.labels or { "YES", "NO" }
    drawCenteredText(labels[1], x + w / 2, y + 10, 0.62)
    drawCenteredText(labels[2], x + w / 2, y + 24, 0.62)
    local row = state.index == 1 and 10 or 24
    drawCursor(x + 10, y + row, 0.62)
  end

  local function isChoiceLike(state)
    return state and (state.screenId == "ChoiceBox"
      or state.onChoose ~= nil and state.index ~= nil
      or state.labels ~= nil and state.index ~= nil)
  end
  
  local function choiceBelongsToWideBattle(state)
    if not (state and activeBattle and isChoiceLike(state)) then return false end
    if activeBattle.blankForAskName then return false end
    local stack = activeBattle.game and activeBattle.game.stack
    local states = stack and stack.states or {}
    local idx
    for i = #states, 1, -1 do
      if states[i] == state then idx = i break end
    end
    if not idx then return false end
    for i = idx - 1, 1, -1 do
      local under = states[i]
      if under == activeBattle then return true end
      if under and under.isBattle then return under == activeBattle end
    end
    return false
  end

  -- Correção Master: Extração extremamente rigorosa e segura do nome da classe do Box de Level Up
  local function isStatsBox(state)
    if not state then return false end
    
    local cname = ""
    if type(state.class) == "table" and state.class.name then
        cname = tostring(state.class.name)
    elseif type(state.class) == "string" then
        cname = state.class
    end
    
    local sid = tostring(state.screenId or state.__name or state.kind or "")
    local full = (cname .. " " .. sid):lower()
    
    -- Blindagem para não interceptar outras janelas baseadas em stats acidentalmente
    if full:find("summary") or full:find("party") or full:find("bag") then
        return false
    end
    
    if full:find("statsbox") or full:find("levelup") then 
        return true 
    end
    
    -- Se não conseguimos ler o nome da classe, intercepta pelo comportamento "Duck Typing"
    if state.stats and type(state.stats) == "table" and state.stats.hp and state.stats.attack and state.stats.defense then 
        return true 
    end
    
    return false
  end

  local function drawCustomStatsBox(state, game)
    local mon = state.mon
    local stats = state.stats or (mon and mon.stats)
    if not stats then return end
    
    -- Dimensões ajustadas para ficar visivelmente menor
    local w, h = 88, 64
    
    -- Centralização matemática perfeita no meio da tela (LOGICAL_W=304, LOGICAL_H=144)
    local x = math.floor((LOGICAL_W - w) / 2)
    local y = math.floor((LOGICAL_H - h) / 2)
    
    -- Renderiza usando exclusivamente o estilo nativo (padrão) de caixas do seu Mod.
    love.graphics.setColor(1, 1, 1, 1)
    drawMenuBox(x, y, w, h)
    
    local sc = 0.52
    local startY = y + 6
    local stepY = 10
    
    local function drawStat(name, val, row)
       drawText(name, x + 8, startY + row * stepY, sc)
       local valStr = tostring(val)
       drawText(valStr, x + w - 8 - width(valStr)*sc, startY + row * stepY, sc)
    end
    
    drawStat("MAX HP", stats.hp or 0, 0)
    drawStat("ATTACK", stats.attack or 0, 1)
    drawStat("DEFENSE", stats.defense or 0, 2)
    drawStat("SPEED", stats.speed or 0, 3)
    drawStat("SPECIAL", stats.special or 0, 4)
    
    -- Pokeball inferior para indicar que a janela pode ser fechada/continuada
    if activeBattle and (activeBattle.frame or 0) % 60 < 30 then
      drawMessagePokeball(x + w - 10, y + h - 10)
    end
  end

  textBoxBelongsToWideBattle = function(state)
    if not (state and state.isTextBox and activeBattle) then return false end
    if activeBattle.blankForAskName then return false end
    return true
  end

  local function drawBattleTextBoxWide(state)
    local safeLeft = LEFT_X
    local safeWidth = LOGICAL_W - LEFT_X * 2
    local groupScale = safeWidth / MENU_W
    local originalBottom = MENU_Y + MENU_H
    local scaledTop = originalBottom - MENU_H * groupScale

    love.graphics.push()
    love.graphics.translate(safeLeft, scaledTop - MENU_Y * groupScale)
    love.graphics.scale(groupScale, groupScale)

    love.graphics.setColor(1, 1, 1, 1)
    if CustomTheme.message_bg then
      drawCustomBg(CustomTheme.message_bg, MENU_X, MENU_Y, MENU_W, MENU_H, "bottom-center")
    else
      drawMenuBox(MENU_X, MENU_Y, MENU_W, MENU_H)
    end
    
    local shown = state and state.shown or {}
    local count = math.min(2, #shown)
    if count > 0 then
      local messageScale, messageStep = 0.82, 9
      local totalH = count * messageStep
      local firstY = MENU_Y + (MENU_H - totalH) / 2
      for i = 1, count do
        drawCodeLineScaled(shown[i], MENU_X + 12,
          firstY + (i - 1) * messageStep, messageScale)
      end
    end
    if state and (state.waiting or (state.done and not state.choice and not state.auto))
       and (state.blink or 0) < 30 then
      drawMessagePokeball(MENU_X + MENU_W - 10, MENU_Y + 32)
    end
    love.graphics.pop()
  end

  local function findTopBattleOverlay(states, battleIndex)
    if not states then return nil end
    local first = math.max(1, battleIndex or 1)
    for i = #states, first, -1 do
      local st = states[i]
      if screenIsBattleOverlay(st, "PartyMenu")
         or screenIsBattleOverlay(st, "BagMenu")
         or screenIsBattleOverlay(st, "SummaryMenu")
         or (st and st.isTextBox and textBoxBelongsToWideBattle(st))
         or isChoiceLike(st) then
        return st
      end
    end
    return nil
  end

  local function drawBattleOverlayScreen(state, game)
    if screenIsBattleOverlay(state, "PartyMenu") then drawNativePartyScreen(state, game); return true end
    if screenIsBattleOverlay(state, "BagMenu") then drawBagScreen(state, game); return true end
    if screenIsBattleOverlay(state, "SummaryMenu") then drawSummaryScreen(state, game); return true end
    if isChoiceLike(state) then
      local stack = activeBattle and activeBattle.game and activeBattle.game.stack
      local states = stack and stack.states or {}
      local idx
      for i = #states, 1, -1 do
        if states[i] == state then idx = i break end
      end
      if idx then
        for i = idx - 1, 1, -1 do
          if textBoxBelongsToWideBattle(states[i]) then
            drawBattleTextBoxWide(states[i])
            break
          end
          if states[i] == activeBattle then break end
        end
      end
      drawChoiceOverlay(state, game)
      return true
    end
    if screenIsBattleOverlay(state, "TextBox") then
      drawBattleTextBoxWide(state)
      return true
    end
    return false
  end

  local function drawBottomUI(battle)
    if not battle or battle.safari or battle.demo then return end

    local safeLeft = LEFT_X
    local safeWidth = LOGICAL_W - LEFT_X * 2
    local groupScale = safeWidth / MENU_W
    local originalBottom = MENU_Y + MENU_H
    local scaledTop = originalBottom - MENU_H * groupScale

    love.graphics.push()
    love.graphics.translate(safeLeft, scaledTop - MENU_Y * groupScale)
    love.graphics.scale(groupScale, groupScale)

    if battle.phase == "moveSelect" then drawMoveMenu(battle)
    elseif battle.phase == "menu" then drawDefaultMenu(battle)
    elseif battle.phase == "messages" then drawMessageBox(battle) end

    love.graphics.pop()
  end

  mod.hooks:wrap("battle.status_hud_visible", function(next, battle)
    if battle and not battle.safari and not battle.demo then
      activeBattle = battle
      return false
    end
    return next(battle)
  end, 300)

  mod.hooks:wrap("battle.bottom_ui_visible", function(next, battle)
    if battle and activeBattle == battle and not battle.safari and not battle.demo then
      if battle.blankForAskName then return next(battle) end
      return false
    end
    return next(battle)
  end, 300)

  local menuInputState = { left = false, right = false }
  mod.hooks:wrap("core.update", function(next, game, dt)
    local ok, selectedTheme = pcall(mod.options.get, mod.options, "ui_theme")
    local newTheme = (ok and selectedTheme) or "default"
    
    if newTheme ~= currentLoadedTheme then
      LoadCustomAssets(newTheme)
      currentLoadedTheme = newTheme
    end

    if game and game.save and game.save.options then
      game.save.options.battleLayout = "og"
    end

    local battle = activeBattle
    local input = game and game.input
    local visual
    if battle and battle.phase == "menu" and not battle.safari and not battle.demo then
      visual = math.max(1, math.min(4,
        battle.wideMenuIndex or nativeToVisual[battle.menuIndex or 1] or 1))
      local leftDown = input and input.isDown and input:isDown("left") or false
      local rightDown = input and input.isDown and input:isDown("right") or false
      local leftPressed = leftDown and not menuInputState.left
      local rightPressed = rightDown and not menuInputState.right
      menuInputState.left, menuInputState.right = leftDown, rightDown
      
      local moved = false
      if leftPressed then 
        visual = visual > 1 and visual - 1 or 4
        moved = true
      elseif rightPressed then 
        visual = visual < 4 and visual + 1 or 1
        moved = true
      end
      
      battle.wideMenuIndex = visual
      battle.menuIndex = visualToNative[visual] or 1
      
      if input then
        local dirs = {"up", "down", "left", "right"}
        for _, d in ipairs(dirs) do
          pcall(function() input:clear(d) end)
          pcall(function() input:consume(d) end)
        end
      end
      
      if moved and game.audio and game.audio.playSound then
        local played = pcall(function() game.audio:playSound("ui_cursor") end)
        if not played then played = pcall(function() game.audio:playSound("ui/cursor") end) end
        if not played then pcall(function() game.audio:playSound("blip") end) end
      end
    else
      menuInputState.left, menuInputState.right = false, false
    end

    local top = game and game.stack and game.stack.top and game.stack:top()
    if top and top.kind == "bag" and activeBattle
       and (top.screenId == "BagMenu" or top.kind == "bag") then
      local l = input and input.isDown and input:isDown("left") or false
      local r = input and input.isDown and input:isDown("right") or false
      top.wideBagInput = top.wideBagInput or { left = false, right = false }
      local lp = l and not top.wideBagInput.left
      local rp = r and not top.wideBagInput.right
      top.wideBagInput.left, top.wideBagInput.right = l, r
      top.wideBagTab = top.wideBagTab or 1
      if lp or rp then
        top.wideBagTab = 3 - top.wideBagTab
        top.index = 1
        top.scroll = 0
        if input then
            pcall(function() input:clear("left") end)
            pcall(function() input:clear("right") end)
            pcall(function() input:consume("left") end)
            pcall(function() input:consume("right") end)
        end
      end
      rebuildBagCategory(top, game)
    end

    next(game, dt)

    local topAfter = game and game.stack and game.stack.top and game.stack:top()
    if topAfter and topAfter.kind == "bag" and activeBattle
       and (topAfter.screenId == "BagMenu" or topAfter.kind == "bag") then
      rebuildBagCategory(topAfter, game)
    end

    if battle and battle.phase == "menu" and visual then
      battle.wideMenuIndex = visual
      battle.menuIndex = visualToNative[visual] or 1
    end
  end, 300)

  mod.hooks:wrap("battle.move_grid_navigation", function(next, battle)
    if battle and activeBattle == battle then return true end
    return next(battle)
  end, 300)

  mod.hooks:wrap("screen.render_visible", function(next, state)
    if not activeBattle then return next(state) end
    if screenIsBattleOverlay(state, "PartyMenu")
       or screenIsBattleOverlay(state, "BagMenu")
       or screenIsBattleOverlay(state, "SummaryMenu")
       or (state and state.isTextBox and activeBattle and not activeBattle.blankForAskName)
       or choiceBelongsToWideBattle(state)
       or isStatsBox(state) then
      return false
    end
    return next(state)
  end, 300)

  mod.events:on("battle.started", function(ev)
    activeBattle = ev and ev.battle or nil
    if activeBattle then
      expAnimations[activeBattle] = nil
    end
  end)
  mod.events:on("battle.exp_gained", function(ev)
    local battle, mon = ev and ev.battle, ev and ev.mon
    if not (battle and battle.player and battle.player.mon == mon) then return end
    local gained = math.max(0, math.floor(ev.gained or 0))
    local toExp = math.max(0, math.floor(mon.exp or 0))
    if gained <= 0 then return end
    local state = expAnimations[battle]
    local fromExp = math.max(0, toExp - gained)
    if state and state.toExp == fromExp and state.displayExp ~= nil then
      fromExp = state.displayExp
    end
    expAnimations[battle] = {
      fromExp = fromExp,
      toExp = toExp,
      displayExp = fromExp,
      tick = 0,
      lastFrame = nil,
    }
  end)
  mod.events:on("battle.ended", function(ev)
    if ev and ev.battle then
      expAnimations[ev.battle] = nil
    end
    if not ev or not ev.battle or ev.battle == activeBattle then activeBattle = nil end
  end)

  do
    local SummaryMenu = require("src.ui.SummaryMenu")
    if not SummaryMenu._gen1WideUIWrapped then
      SummaryMenu._gen1WideUIWrapped = true
      local nativeUpdate = SummaryMenu.update
      SummaryMenu.update = function(self, dt)
        local input = self.game.input
        if input:wasPressed("left") or input:wasPressed("right") then
          self.page = self.page == 1 and 2 or 1
          return
        end
        if input:wasPressed("a") or input:wasPressed("b") then
          self.game.stack:pop()
          return
        end
        return nativeUpdate(self, dt)
      end
    end
  end

  mod.hooks:wrap("battle.overlay", function(next, battle)
    if activeBattle == battle then
      return
    end
    return next(battle)
  end, 1000)

  mod.hooks:wrap("render.hud", function(next, game, viewport)
    local battle = activeBattle
    if not battle then
      return next(game, viewport)
    end
    local stack = game and game.stack
    local states = stack and stack.states or {}
    if battle then
      local onStack = false
      for _, st in ipairs(states) do if st == battle then onStack = true break end end
      if not onStack then activeBattle, battle = nil, nil end
    end

    if not battle then return end

    local battleIndex
    for i = #states, 1, -1 do
      if states[i] == battle then battleIndex = i break end
    end

    -- Armazena a janela de StatsBox caso esteja ativa, para desenhá-la sempre no exato final.
    local statsBoxState = nil
    if battleIndex then
      for i = battleIndex + 1, #states do
        if isStatsBox(states[i]) then
          statsBoxState = states[i]
          break
        end
      end
    end

    local function renderStatsBoxIfPresent(vp)
      if not statsBoxState then return end
      local ww, wh = tonumber(vp and vp.width) or 0, tonumber(vp and vp.height) or 0
      if ww <= 0 or wh <= 0 then return end
      local s_scale, s_ox, s_oy = getResponsiveTransform(vp)
      if not s_scale then return end
      love.graphics.push("all")
      love.graphics.translate(s_ox, s_oy)
      love.graphics.scale(s_scale, s_scale)
      drawCustomStatsBox(statsBoxState, game)
      love.graphics.pop()
      love.graphics.setColor(1, 1, 1, 1)
    end

    local battleTextBox
    if battleIndex and not battle.blankForAskName then
      for i = #states, battleIndex + 1, -1 do
        local st = states[i]
        if st and st.isTextBox and textBoxBelongsToWideBattle(st) then
          battleTextBox = st
          break
        end
      end
    end
    local overlay = findTopBattleOverlay(states, battleIndex)

    if battleTextBox then
      local ww, wh = tonumber(viewport and viewport.width) or 0,
                    tonumber(viewport and viewport.height) or 0
      if ww > 0 and wh > 0 then
         local scale, ox, oy, frameScale = getResponsiveTransform(viewport)
         if scale then
            local isPortrait = (ww < wh)
            local bot_oy = oy + 34 * frameScale
            if isPortrait then
              bot_oy = oy
            end
            love.graphics.push("all")
            love.graphics.translate(ox, bot_oy)
            love.graphics.scale(scale, scale)
            drawBattleTextBoxWide(battleTextBox)
            love.graphics.pop()
            love.graphics.setColor(1, 1, 1, 1)
         end
      end
      renderStatsBoxIfPresent(viewport)
      return
    end

    if battle.blankForAskName then
      if overlay then
        local ww, wh = tonumber(viewport and viewport.width) or 0,
                      tonumber(viewport and viewport.height) or 0
        if ww > 0 and wh > 0 then
           local scale, ox, oy, frameScale = getResponsiveTransform(viewport)
           if scale then
              local isPortrait = (ww < wh)
              local bot_oy = oy + 34 * frameScale
              if isPortrait then
                bot_oy = oy
              end
              love.graphics.push("all")
              love.graphics.translate(ox, bot_oy)
              love.graphics.scale(scale, scale)
              love.graphics.pop()
              love.graphics.setColor(1, 1, 1, 1)
           end
        end
      end
      renderStatsBoxIfPresent(viewport)
      return
    end

    if not statusVisible(battle) then 
      renderStatsBoxIfPresent(viewport)
      return 
    end

    if overlay then
      local scale = getResponsiveTransform(viewport)
      if scale then
         local ww = tonumber(viewport and viewport.width) or 0
         local wh = tonumber(viewport and viewport.height) or 0
         local overlayX = (ww - LOGICAL_W * scale) / 2
         local overlayY = (wh - LOGICAL_H * scale) / 2
         love.graphics.push("all")
         love.graphics.translate(overlayX, overlayY)
         love.graphics.scale(scale, scale)
         drawBattleOverlayScreen(overlay, game)
         love.graphics.pop()
         love.graphics.setColor(1, 1, 1, 1)
      end
      renderStatsBoxIfPresent(viewport)
      return
    end

    if not battleIndex then 
      renderStatsBoxIfPresent(viewport)
      return 
    end
    
    for i = battleIndex + 1, #states do
      local st = states[i]
      if st and st.render and not st.isTextBox and not isChoiceLike(st) and not isStatsBox(st) then
        love.graphics.push("all")
        pcall(function() st:render(game, viewport) end)
        love.graphics.pop()
        love.graphics.setColor(1, 1, 1, 1)
      end
    end

    local ww, wh = tonumber(viewport and viewport.width) or 0,
                  tonumber(viewport and viewport.height) or 0
    if ww <= 0 or wh <= 0 then return end

    local scale, ox, oy, frameScale = getResponsiveTransform(viewport)
    if not scale then return end

    local extraWidth = responsiveLogicalWidth(viewport, frameScale) - LOGICAL_W
    local shiftLeft = extraWidth / 2
    local shiftRight = -shiftLeft

    local effScale = topUIScaleMultiplier()

    local safeLeftX = LEFT_X
    if not wideTopEnabled() then safeLeftX = safeLeftX + shiftLeft end

    local safePlayerX = LOGICAL_W - LEFT_X - PANEL_W
    if not wideTopEnabled() then safePlayerX = safePlayerX + shiftRight end

    local isPortrait = (ww < wh)
    local top_oy = oy
    local bot_oy = oy + 34 * frameScale
    
    if isPortrait then
      top_oy = oy
      bot_oy = oy
    end

    love.graphics.push("all")
    love.graphics.translate(ox, top_oy)
    love.graphics.scale(scale, scale)

    love.graphics.push()
    love.graphics.translate(math.floor(safeLeftX - LEFT_X * (effScale - 1)),
      math.floor(TOP_Y - TOP_Y * (effScale - 1)))
    love.graphics.scale(effScale, effScale)
    panel(battle.enemy, 0, 0, "left", battle)
    love.graphics.pop()

    love.graphics.push()
    local pivotPX, pivotPY = safePlayerX + PANEL_W, PLAYER_Y + PANEL_H
    love.graphics.translate(math.floor(pivotPX - pivotPX * effScale),
      math.floor(pivotPY - pivotPY * effScale))
    love.graphics.scale(effScale, effScale)
    panel(battle.player, safePlayerX, PLAYER_Y, "right", battle)
    if battle.player and battle.player.mon then
      drawExpBar(battle, safePlayerX + 4, PLAYER_Y + 34, EXP_BAR_W - 8)
    end
    love.graphics.pop()

    love.graphics.pop()

    local lowerScale = bottomUIScaleMultiplier()
    love.graphics.push("all")
    love.graphics.translate(ox, bot_oy)
    love.graphics.scale(scale, scale)
    if lowerScale ~= 1 then
      local pX = MENU_X + MENU_W / 2
      local pY = MENU_Y + MENU_H / 2
      love.graphics.translate(pX, pY)
      love.graphics.scale(lowerScale, lowerScale)
      love.graphics.translate(-pX, -pY)
    end
    drawBottomUI(battle)
    love.graphics.pop()
    
    love.graphics.setColor(1, 1, 1, 1)
    
    -- Finalmente, garante que o Stats Box seja desenhado isolado AQUI, 
    -- 100% por cima de todas as camadas do HUD e UI, devidamente centralizado.
    renderStatsBoxIfPresent(viewport)
  end, 300)
end