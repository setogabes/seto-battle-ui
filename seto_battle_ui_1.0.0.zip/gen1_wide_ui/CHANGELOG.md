# Gen 1 Wide Battle UI 0.2.79

- Corrected Pokemon Classic lowercase `i`/`l` TTF advances so words no longer develop large gaps.
- Made the selected move's black keyline one-pixel and deliberately subtle.
- Added a native SummaryMenu sprite fallback/cache so the PKMN STATS page can recover the same resolved front sprite used by Gen1Recomp.
- Preserved all previously approved layout, scaling, battle-layout, PotatoVoxel, and message behavior.
