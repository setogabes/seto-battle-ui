# Gen 1 Wide Battle UI 0.2.78

Test build based on 0.2.77. Keeps the approved 10% selection zoom, removes the experimental drop shadow, adds a thin black outline to the selected move tag, re-centers command text vertically in the reduced boxes, halves the visible gaps between FIGHT/ITEM/PKMN/RUN boxes, and replaces the lower-message triangle with a monochrome Poké Ball prompt indicator.
